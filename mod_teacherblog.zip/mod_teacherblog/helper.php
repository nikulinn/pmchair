<?php

    defined('_JEXEC') or die;

class modTeacherBlogtHelper
{
 public static function getList(&$params)
 {

 }
}
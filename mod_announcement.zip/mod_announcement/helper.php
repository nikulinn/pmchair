<?php

    defined('_JEXEC') or die;

class modAnnouncementHelper
{
 public static function getList(&$params)
 {

 }
}